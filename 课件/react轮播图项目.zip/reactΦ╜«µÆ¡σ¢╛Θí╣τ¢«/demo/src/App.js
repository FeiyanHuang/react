import React, { Component } from 'react';

// 1. 怎么去引入图片？
import image_1 from './images/autumn-3846345_1920.jpg'
import image_2 from './images/dawn-3846778_1920.jpg'
import image_3 from './images/lichterkette-3834926_1920.jpg'

// link => import
import './demo.css'

var images = [image_1 , image_2 , image_3]

// react 相似的内容 map 数组

class App extends Component {
  constructor(props){
    super(props)
    this.state = {
      index : 1 // active类名
    }
  }
  _goNext(){
    var {index} = this.state
    if(index === images.length - 1){
      index = 0
    } else {
      index ++
    }
    this.setState({
      index : index
    })
  }
  _goPrev(){
    var {index } = this.state
    if(index === 0){
      index = images.length - 1
    } else {
      index --
    }
    this.setState({
      index : index
    })
  }
  render() {
    var { index } = this.state
    return (
      <div className='wrap'>
        <ul className='list'>
          {
            // 1. map  key diff _id
            // 2. 括号
            images.map((item ,i)=>(
              <li className={`item ${index === i ? 'active' : ''}`} key={i}><img src={item} alt=""/></li>
            ))
          }
        </ul>
        {/* jsx < 一个标签的开始 */}
        <button 
          className="btn left"
          onClick={()=>this._goPrev()}
        > {'<'} </button>
        <button 
          className="btn right"
          onClick={()=>this._goNext()}
        > > </button>
        {/* 打包编译 */}
      </div>
    );
  }
}

export default App;
