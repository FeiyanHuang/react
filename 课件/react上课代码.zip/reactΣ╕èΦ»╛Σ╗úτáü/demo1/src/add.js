var add = function(a,b){
    return a+b
}

var jian = function(a,b){
    return a-b
}

export {jian}
export default add

