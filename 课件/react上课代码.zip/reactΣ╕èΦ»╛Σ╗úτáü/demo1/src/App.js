import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import Button ,{Nav} from './Button'

import Input from './Input'

//类方式
// class Nav extends Component {
//   constructor() {
//     super()
//   }
//   render() {
//     return (
//       <div style={{ color: "white", backgroundColor: "black" }}>Skipper</div>
//     )
//   }
// }

// 函数方式
// const Button = function(){
//   return (
//     <button type="button">来自Button组件</button>
//   )
// }

class App extends React.Component {
  constructor() {
    super()

    // this.state = {
    //   like: false
    // }
    // this.hanleClick.bind(this)
  }
  hanleClick() {
    // this.setState(
    //   {
    //     like: !this.state.like
    //   }
    // )
    console.log('你在调用handleClick事件')
  }
  render() {
    console.log('App组件更新')
    return (
      <div>
        {/* <Nav />
        <Button></Button>
        <Button></Button>
        <Button></Button>
        <Button></Button>
        <button type="button" style={this.state.like ? { color: "red" } : { color: "black" }}
          onClick={() => this.hanleClick()}
        >
          {
            this.state.like ? "已赞" : "喜欢"
          }
        </button> */}


          {/* <p onClick={()=>this.hanleClick()}>点击看this</p> */}
        {/* <Input></Input>
        <Button></Button>
        <p onClick={()=>this.setState({})}>点击更新App组件</p> */}
        <hr/>
        
        <Nav title={"标题"}>
          <h3>这是一个传递的chidren</h3>
          <h3>这是一个传递的chidren 2</h3>
          <Button name="点击一下你就上天"></Button>
          <Button name="点击一下百度一下"></Button>
        </Nav>

      </div>


    )
  }
}



export default App;


